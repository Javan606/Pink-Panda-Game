# Pink Panda: Sakura Coin Run 3D — iPhone IPA build project

This is a **complete native iOS project**, not a precompiled IPA. It wraps the existing original offline WebGL game in Apple's native `WKWebView`. The native Swift code, app icon, complete game and CI build workflow are included.

## Make the IPA without a Mac (GitHub Actions)

1. Sign in at github.com and create a new **private** repository. Enable GitHub Actions for it.
2. Unzip this package in Files, then upload its contents to the root of the repository, **preserving the `.github/workflows` folder**. On iPhone this is easier using a GitHub-capable code editor or a remote development environment; uploading the ZIP alone does **not** unpack it into the repository.
3. If the workflow did not start from the push, open GitHub repository > **Actions** > **Build Pink Panda 3D IPA (unsigned)** > **Run workflow**.
4. When the build succeeds, open the workflow run and download its artifact, `PinkPanda3D-unsigned-IPA`. The artifact is a ZIP from GitHub containing **`PinkPanda3D-unsigned.ipa`**.
5. Extract the workflow artifact in the iPhone Files app to get the actual `.ipa` file.
6. Open **SideStore** on your iPhone, ensure LocalDevVPN/Wi-Fi are working, then choose `+` and select the `.ipa`. SideStore should attempt to sign and install it using your Apple Account. Successful installation depends on the signing environment and iOS compatibility.

GitHub-hosted macOS runners have usage limits/charges according to the account, repository visibility and plan. For a small proof of concept, inspect the quoted quota in your account before triggering the build.

**Why unsigned?** Compiling an Apple iOS executable requires Apple's macOS Xcode build tools. This project generates a genuine iOS .app executable on a cloud Mac, packages it in an IPA and leaves code-signing to SideStore. An IPA created without compiling an actual iOS executable would not install. The build and install have not been verified on an actual iPhone yet.

## Build on a Mac (alternative)

```sh
brew install xcodegen
xcodegen generate
xcodebuild -project PinkPanda3D.xcodeproj -scheme PinkPanda3D -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath ./DerivedData CODE_SIGNING_ALLOWED=NO build
mkdir -p Packaging/Payload
cp -R DerivedData/Build/Products/Release-iphoneos/PinkPanda3D.app Packaging/Payload/
(cd Packaging && zip -qry ../PinkPanda3D-unsigned.ipa Payload)
```

## About the implementation

- Built as a standard native iOS `UIKit` application.
- Native `WKWebView` plays the complete local WebGL game with **no internet connection or API required**.
- Portrait orientation and immersive, full-screen UI.
- Offline score handling depends on WebKit localStorage availability.
- iOS 15 or later and an iPhone with WebGL-capable WKWebView are required.
- Game graphics are procedural and based on the supplied Pink Panda character sheet.
- App icon and original game assets are included; original character sheet is not embedded in the app.
- There is no automatic server connection, analytics, user account, or purchase system.

## Limits

A cloud macOS Xcode compile step is still necessary. This package contains **source code only, not an IPA**. The automated build workflow is supplied but was not triggered here. SideStore may reject an app depending on the exact provisioning/certificate environment; an actual install test is necessary.
